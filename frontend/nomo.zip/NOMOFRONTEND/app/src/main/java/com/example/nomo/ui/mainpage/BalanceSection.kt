package com.example.nomo.ui.mainpage

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nomo.ui.theme.YouAreOwedColor
import com.example.nomo.ui.theme.YouOweColor
import com.example.nomo.ui.theme.AccentColorYouOwe
import com.example.nomo.ui.theme.AccentColorYouOwed
import com.example.nomo.ui.theme.SFProDisplay
import com.example.nomo.ui.theme.SFProText
import com.example.nomo.ui.theme.SecondaryTextOnBackground
import com.example.nomo.ui.theme.SecondaryTextOnPrimary

@Composable
fun BalanceSection(oweAmount: String, owedAmount: String) {
    val totalCharacters = oweAmount.length + owedAmount.length
    val isVertical = totalCharacters > 16 // Определяем, нужно ли вертикальное выравнивание

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        Text(
            text = "Ваш баланс:",
            color = SecondaryTextOnBackground,
            fontSize = 14.sp,
            fontFamily = SFProText,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        if (isVertical) {
            // Вертикальное отображение
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp) // Отступ между карточками
            ) {
                BalanceCard("Вы должны", oweAmount, YouOweColor, AccentColorYouOwe, isVertical)
                BalanceCard("Вам должны", owedAmount, YouAreOwedColor, AccentColorYouOwed, isVertical)
            }
        } else {
            // Горизонтальное отображение
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                BalanceCard("Вы должны", oweAmount, YouOweColor, AccentColorYouOwe, isVertical)
                BalanceCard("Вам должны", owedAmount, YouAreOwedColor, AccentColorYouOwed, isVertical)
            }
        }
    }
}

@Composable
fun BalanceCard(
    title: String,
    amount: String,
    bgColor: Color,
    lineColor: Color,
    isVertical: Boolean = false // Параметр для определения режима (по умолчанию false)
) {
    Column(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(24.dp))
            .padding(16.dp)
            .then(
                if (isVertical) Modifier.fillMaxWidth() // В вертикальном режиме занимаем всю ширину
                else Modifier // В горизонтальном режиме оставляем дефолтный вид
            ),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = title,
            fontSize = 14.sp,
            fontFamily = SFProDisplay,
            fontWeight = FontWeight.SemiBold,
            color = SecondaryTextOnPrimary
        )
        Box(
            modifier = Modifier
                .height(2.dp)
                .background(lineColor)
                .then(
                    if (isVertical) Modifier.fillMaxWidth() // В вертикальном режиме линия на всю ширину
                    else Modifier.width(142.dp) // В горизонтальном режиме фиксированная ширина
                )
        )
        Text(
            text = amount,
            fontSize = 32.sp,
            fontFamily = SFProDisplay,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Start)
        )
    }
}