package com.example.nomo.ui.mainpage

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.nomo.ui.common.BottomBar
import com.example.nomo.ui.common.TopBar

@Composable
@Preview(showBackground = true)
fun MainScreen() {
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars), // Добавляем отступы для системных элементов
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues) // Учитываем отступы
        ) {
            TopBar()
            GreetingUser("samplename")
            BalanceSection("756,00₽", "1340,00₽")

            DebtList(
                listOf(
                    Debt("Иван Борисов", "331₽", false),
                    Debt("Илья Макаров", "8912₽", true),
                    Debt("Артем Рожков", "87 091₽", true)
                ),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.height(8.dp))
            BottomBar()
        }
    }
}