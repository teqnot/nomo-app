package com.example.nomo.ui.mainpage

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nomo.R
import com.example.nomo.ui.theme.DividerColorBalances
import com.example.nomo.ui.theme.SFProText
import com.example.nomo.ui.theme.YouOweColor
import com.example.nomo.ui.theme.YouAreOwedColor

data class Debt(val name: String, val amount: String, val isOwedToMe: Boolean)

@Composable
fun DebtList(debts: List<Debt>, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier
        .fillMaxWidth()
        .padding(20.dp)
    ) {
        items(debts) { debt ->
            Spacer(modifier = Modifier.height(8.dp))
            DebtItem(debt)
            Spacer(modifier = Modifier.height(4.dp))
            HorizontalDivider(thickness = 1.dp, color = DividerColorBalances)
        }
    }
}

@Composable
fun DebtItem(debt: Debt) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Левая часть: аватар и имя
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f) // Занимает всё доступное пространство
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_avatar),
                contentDescription = "Avatar",
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = debt.name,
                fontSize = 16.sp,
                fontFamily = SFProText,
                fontWeight = FontWeight.Bold
            )
        }

        // Правая часть: сумма и стрелка
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(
                        if (debt.isOwedToMe) YouOweColor else YouAreOwedColor,
                        RoundedCornerShape(5.dp)
                    )
                    .padding(4.dp)
            ) {
                Text(
                    text = debt.amount,
                    fontFamily = SFProText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Image(
                painter = painterResource(id = R.drawable.ic_nav_forward),
                contentDescription = "Arrow"
            )
        }
    }
}