package com.example.pract5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private ListView categoriesListView;
    private ArrayList<String> categories = new ArrayList<>(Arrays.asList("Яблоки", "Бананы", "Груши"));
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Загрузка пользовательских категорий
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String customCategories = prefs.getString("custom_categories", "");
        if (!customCategories.isEmpty()) {
            categories.addAll(Arrays.asList(customCategories.split(",")));
        }

        categoriesListView = findViewById(R.id.categoriesListView);
        adapter = new ArrayAdapter<>(this, R.layout.list_item_white, categories);
        categoriesListView.setAdapter(adapter);

        categoriesListView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(MainActivity.this, FruitsActivity.class);
            intent.putExtra("category", categories.get(position));
            startActivity(intent);
        });

        Button btnAddCategory = findViewById(R.id.btnAddCategory);
        btnAddCategory.setOnClickListener(v -> showAddCategoryDialog());

        // Кнопки для других активностей
        Button btnRecycler = findViewById(R.id.btnRecycler);
        Button btnScroll = findViewById(R.id.btnScroll);
        Button btnSpinner = findViewById(R.id.btnSpinner);

        btnRecycler.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RecyclerActivity.class));
        });

        btnScroll.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, ScrollActivity.class));
        });

        btnSpinner.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SpinnerActivity.class));
        });

        findViewById(R.id.btnDebugClear).setOnClickListener(v -> {
            clearSharedPreferences();
            categories.clear();
            categories.addAll(Arrays.asList("Яблоки", "Бананы", "Груши"));
            adapter.notifyDataSetChanged();
        });
    }

    public void clearSharedPreferences() {
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear(); // Очищает все данные
        editor.apply(); // или commit() для синхронного сохранения

        // Если нужно показать пользователю сообщение
        Toast.makeText(this, "Все данные очищены", Toast.LENGTH_SHORT).show();
    }

    private void showAddCategoryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Добавить новую категорию");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Добавить", (dialog, which) -> {
            String newCategory = input.getText().toString().trim();
            if (!newCategory.isEmpty()) {
                // Сохраняем в SharedPreferences
                SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                String existing = prefs.getString("custom_categories", "");
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("custom_categories",
                        existing.isEmpty() ? newCategory : existing + "," + newCategory);
                editor.apply();

                // Обновляем список
                categories.add(newCategory);
                adapter.notifyDataSetChanged();
            }
        });
        builder.setNegativeButton("Отмена", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}