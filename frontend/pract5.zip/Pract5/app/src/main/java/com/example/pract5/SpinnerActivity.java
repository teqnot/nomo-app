package com.example.pract5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class SpinnerActivity extends AppCompatActivity {
    private TextView tvFruitsList;
    private ArrayList<String> categories;
    private HashMap<String, ArrayList<String>> fruitsMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        tvFruitsList = findViewById(R.id.tvFruitsList);
        Spinner categorySpinner = findViewById(R.id.spinner);

        initData();

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = categories.get(position);
                displayFruitsForCategory(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tvFruitsList.setText("Выберите категорию");
            }
        });
    }

    private void initData() {
        categories = new ArrayList<>(Arrays.asList("Яблоки", "Бананы", "Груши"));

        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String customCategories = prefs.getString("custom_categories", "");
        if (!customCategories.isEmpty()) {
            categories.addAll(Arrays.asList(customCategories.split(",")));
        }

        fruitsMap = new HashMap<>();
        fruitsMap.put("Яблоки", new ArrayList<>(Arrays.asList("Гренни Смит", "Гала", "Фуджи")));
        fruitsMap.put("Бананы", new ArrayList<>(Arrays.asList("Кавендиш", "Леди Фингер")));
        fruitsMap.put("Груши", new ArrayList<>(Arrays.asList("Конференция", "Вильямс")));

        for (String category : categories) {
            String fruits = prefs.getString("fruits_" + category, "");
            if (!fruits.isEmpty()) {
                ArrayList<String> fruitList = new ArrayList<>(Arrays.asList(fruits.split(",")));
                if (fruitsMap.containsKey(category)) {
                    fruitsMap.get(category).addAll(fruitList);
                } else {
                    fruitsMap.put(category, fruitList);
                }
            }
        }
    }

    private void displayFruitsForCategory(String category) {
        StringBuilder sb = new StringBuilder();
        sb.append("Сорта в категории '").append(category).append("':\n\n");

        if (fruitsMap.containsKey(category)) {
            for (String fruit : fruitsMap.get(category)) {
                sb.append("• ").append(fruit).append("\n");
            }
        } else {
            sb.append("Пока нет сортов в этой категории");
        }

        tvFruitsList.setText(sb.toString());
    }
}