package com.example.pract5;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class ScrollActivity extends AppCompatActivity {
    private LinearLayout scrollContent;
    private EditText etNewText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scroll);

        // Кнопка назад
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        scrollContent = findViewById(R.id.scrollContent);
        etNewText = findViewById(R.id.etNewText);

        Button btnAddText = findViewById(R.id.btnAddText);
        btnAddText.setOnClickListener(v -> {
            String text = etNewText.getText().toString().trim();
            if (!text.isEmpty()) {
                addNewTextView(text);
                etNewText.setText("");
            }
        });
    }

    private void addNewTextView(String text) {
        TextView newTextView = new TextView(this);
        newTextView.setText(text);
        newTextView.setTextColor(ContextCompat.getColor(this, R.color.white));
        newTextView.setTextSize(16);
        newTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        newTextView.setPadding(0, 32, 0, 32);

        scrollContent.addView(newTextView, scrollContent.getChildCount() - 2);
    }
}
