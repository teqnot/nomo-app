package com.example.pract5;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecyclerActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FruitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        // Кнопка назад
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<FruitItem> items = loadAllFruits();
        adapter = new FruitAdapter(items);
        recyclerView.setAdapter(adapter);
    }

    private List<FruitItem> loadAllFruits() {
        List<FruitItem> items = new ArrayList<>();
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        // Системные категории
        addFruitsForCategory(items, "Яблоки", R.drawable.ic_apple, prefs);
        addFruitsForCategory(items, "Бананы", R.drawable.ic_banana, prefs);
        addFruitsForCategory(items, "Груши", R.drawable.ic_pear, prefs);

        // Пользовательские категории
        String customCategories = prefs.getString("custom_categories", "");
        if (!customCategories.isEmpty()) {
            for (String category : customCategories.split(",")) {
                addFruitsForCategory(items, category, R.drawable.ic_launcher_foreground, prefs);
            }
        }

        return items;
    }

    private void addFruitsForCategory(List<FruitItem> items, String category, int iconRes, SharedPreferences prefs) {
        ArrayList<String> fruits = new ArrayList<>();

        // Системные фрукты
        switch (category) {
            case "Яблоки":
                fruits.add("Гренни Смит");
                fruits.add("Гала");
                fruits.add("Фуджи");
                break;
            case "Бананы":
                fruits.add("Кавендиш");
                fruits.add("Леди Фингер");
                break;
            case "Груши":
                fruits.add("Конференция");
                fruits.add("Вильямс");
                break;
        }

        // Пользовательские фрукты
        String customFruits = prefs.getString("fruits_" + category, "");
        if (!customFruits.isEmpty()) {
            fruits.addAll(Arrays.asList(customFruits.split(",")));
        }

        for (String fruit : fruits) {
            items.add(new FruitItem(iconRes, fruit, category));
        }
    }

    private static class FruitItem {
        int imageRes;
        String name;
        String category;

        FruitItem(int imageRes, String name, String category) {
            this.imageRes = imageRes;
            this.name = name;
            this.category = category;
        }
    }

    private static class FruitAdapter extends RecyclerView.Adapter<FruitAdapter.ViewHolder> {
        private final List<FruitItem> items;

        FruitAdapter(List<FruitItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_fruit, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            FruitItem item = items.get(position);
            holder.imageView.setImageResource(item.imageRes);
            holder.nameTextView.setText(item.name);
            holder.categoryTextView.setText(item.category);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;
            TextView nameTextView;
            TextView categoryTextView;

            ViewHolder(View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageView);
                nameTextView = itemView.findViewById(R.id.tvName);
                categoryTextView = itemView.findViewById(R.id.tvCategory);
            }
        }
    }
}
