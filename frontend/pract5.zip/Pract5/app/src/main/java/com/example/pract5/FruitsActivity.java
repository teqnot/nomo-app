package com.example.pract5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FruitsActivity extends AppCompatActivity {
    private ArrayList<String> fruitsList;
    private ArrayAdapter<String> adapter;
    private String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruits);

        category = getIntent().getStringExtra("category");
        TextView tvCategory = findViewById(R.id.tvCategory);
        tvCategory.setText(category);

        fruitsList = new ArrayList<>();
        loadFruits();

        ListView fruitsListView = findViewById(R.id.fruitsListView);
        adapter = new ArrayAdapter<>(this, R.layout.list_item_white, fruitsList);
        fruitsListView.setAdapter(adapter);

        fruitsListView.setOnItemLongClickListener((parent, view, position, id) -> {
            String fruitToDelete = fruitsList.get(position);

            new AlertDialog.Builder(this)
                    .setTitle("Удаление сорта")
                    .setMessage("Удалить сорт \"" + fruitToDelete + "\"?")
                    .setPositiveButton("Удалить", (dialog, which) -> {
                        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                        String fruits = prefs.getString("fruits_" + category, "");

                        if (!fruits.isEmpty()) {
                            String updatedFruits = fruits.replace(fruitToDelete, "").replace(",,", ",");
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("fruits_" + category, updatedFruits);
                            editor.apply();
                        }
                        fruitsList.remove(position);
                        adapter.notifyDataSetChanged();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();

            return true;
        });

        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        Button btnAddFruit = findViewById(R.id.btnAddFruit);
        btnAddFruit.setOnClickListener(v -> showAddFruitDialog());
    }

    private void loadFruits() {
        // Системные фрукты
        switch (category) {
            case "Яблоки":
                fruitsList.add("Гренни Смит");
                fruitsList.add("Гала");
                fruitsList.add("Фуджи");
                break;
            case "Бананы":
                fruitsList.add("Кавендиш");
                fruitsList.add("Леди Фингер");
                break;
            case "Груши":
                fruitsList.add("Конференция");
                fruitsList.add("Вильямс");
                break;
        }

        // Пользовательские фрукты
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String fruits = prefs.getString("fruits_" + category, "");
        if (!fruits.isEmpty()) {
            fruitsList.addAll(Arrays.asList(fruits.split(",")));
        }
    }

    private void showAddFruitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Добавить новый сорт");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Добавить", (dialog, which) -> {
            String newFruit = input.getText().toString().trim();
            if (!newFruit.isEmpty()) {
                addNewFruit(newFruit);
            }
        });
        builder.setNegativeButton("Отмена", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void addNewFruit(String fruit) {
        // Сохраняем в SharedPreferences
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String existing = prefs.getString("fruits_" + category, "");
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("fruits_" + category,
                existing.isEmpty() ? fruit : existing + "," + fruit);
        editor.apply();

        // Обновляем список
        fruitsList.add(fruit);
        adapter.notifyDataSetChanged();
    }
}